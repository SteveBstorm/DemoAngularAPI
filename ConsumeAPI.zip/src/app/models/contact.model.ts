export class Contact {
    Id : number;
    Nom : string;
    Email : string;
    GSM : string;
}