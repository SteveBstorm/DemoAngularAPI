import { Component, OnInit } from '@angular/core';
import { ContactService } from 'src/app/services/contact.service';
import { Contact } from 'src/app/models/contact.model';
import { Subscription } from 'rxjs';
import { NbDialogService } from '@nebular/theme';
import { ConfirmboxComponent } from 'src/app/shared/confirmbox/confirmbox.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-contactlist',
  templateUrl: './contactlist.component.html',
  styleUrls: ['./contactlist.component.scss']
})
export class ContactlistComponent implements OnInit {

  listeContact : Contact[] = [];
  sub : Subscription;
  constructor(private _service : ContactService, private _dialog : NbDialogService, private _router : Router) { }

  ngOnInit(): void {
    this.sub = this._service.contactSubject.subscribe((data : Contact[]) => this.listeContact = data);
    this._service.getAll();
  }

  delete(id : number, nom : string) {
    let ref = this._dialog.open(ConfirmboxComponent, {
      context : {
        name : nom
      },
      closeOnBackdropClick : false
    });

    ref.onClose.subscribe(data => {
      if(data) this._service.delete(id);
    });
  }

  update(id : number) {
    this._router.navigate(['/update', id]);
  }

}
